package vn.ithanh.udocter.service;

/**
 * Created by iThanh on 11/19/2017.
 */

public interface IServiceCallback {
    public void onResponseReceived(int cmd, String resp);
}
