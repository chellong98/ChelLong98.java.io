/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChelLong.javaswing.test;

import ChelLong.javaswing.ui.MayTinhBoTuiUI;

/**
 *
 * @author Long Nguyen Nhat
 */
public class TestMayTinhBoTui {
    public static void main(String[] args) {
        MayTinhBoTuiUI ui = new MayTinhBoTuiUI("máy tính bỏ túi");
        ui.showWindow();
    }
}
