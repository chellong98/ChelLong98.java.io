package pccc.detaikhoahoc.test;

import pccc.quanlytailieu.ui.TimKiemUI;

public class TestTimKiemUI {
	public static void main(String[]args) {
		TimKiemUI ui = new TimKiemUI("Tìm kiếm tài liệu phòng cháy chữa cháy");
		ui.showWidow();
	}
}
