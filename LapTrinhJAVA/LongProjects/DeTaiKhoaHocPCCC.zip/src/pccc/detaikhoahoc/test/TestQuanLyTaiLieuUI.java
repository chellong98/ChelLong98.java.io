package pccc.detaikhoahoc.test;

import pccc.quanlytailieu.ui.QuanLyTaiLieuUI;

public class TestQuanLyTaiLieuUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuanLyTaiLieuUI ui = new QuanLyTaiLieuUI("Quản Lý Thuật Ngữ");
		ui.showWindow();
	}

}
