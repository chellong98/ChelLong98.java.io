package pccc.detaikhoahoc.test;

import pccc.quanlytailieu.ui.LoginUI;

public class TestLoginUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginUI ui = new LoginUI("đăng nhập quản trị tài liệu");
		ui.showWindow();
	}

}
