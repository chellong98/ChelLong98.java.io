package pccc.detaikhoahoc.test;

import pccc.quanlytailieu.ui.XuLyThemMoiUI;

public class TestNhapDuLieuUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XuLyThemMoiUI ui = new XuLyThemMoiUI("nhập dữ liệu");
		ui.showWindow();
	}

}
