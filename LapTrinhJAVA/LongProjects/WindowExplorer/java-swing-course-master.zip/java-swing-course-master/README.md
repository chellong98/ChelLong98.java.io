# Java Swing Course
Khoá học lập trình java swing online

## Thời gian học
- Chiều thứ 7, 15h hàng tuần.

## Cách thức học
- Học online qua hệ thống học trực tuyến.
- Tự làm bài tập và thắc mắc những chỗ không hiểu hoặc không làm được.

## Tham gia lớp học

### Để tham gia vào lớp học, các bạn sẽ phải thực hiện các bước như sau:
- Làm bài tập
- Submit code lên tài khoản github trước giờ học 1 tiếng.
- Share link github chứa code hoặc add tài khoản github: `hoangnghiem205` vào member của project.
- Sau khi hoàn thành, các bạn sẽ nhận được email chứa link vào lớp cho buổi học tiếp theo.

## CHÚ Ý
Nội dung các bài tập, đề bài, mã nguồn tham khảo, thời hạn nộp bài, các bạn có thể tìm thấy trong project này.
