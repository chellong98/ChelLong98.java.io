package ChelLong.javaswing.test;

import ChelLong.javaswing.ui.DictionaryUI;

public class TestDictionaryUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DictionaryUI ui = new DictionaryUI("Từ điển của tôi");
		ui.showWindow();
	}

}
