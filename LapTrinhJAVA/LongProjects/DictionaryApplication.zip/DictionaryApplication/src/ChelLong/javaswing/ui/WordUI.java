package ChelLong.javaswing.ui;

import java.awt.Container;

public class WordUI extends DictionaryUI {

	public WordUI(String title) {
		super(title);
		Show(FindWordUI.wordSelected);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void Show(String word) {
		// TODO Auto-generated method stub
		super.Show(word);
	}

	
	
}
