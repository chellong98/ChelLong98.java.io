Thanks for downloading this theme!

Theme Name: Amoeba
Theme URL: https://bootstrapmade.com/free-one-page-bootstrap-template-amoeba/
Author: BootstrapMade
Author URL: https://bootstrapmade.com