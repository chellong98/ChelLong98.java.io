#include <stdio.h>
#include <stdlib.h>
//Bài tập 7: Tạo hàm đệ qui để tính phần tử thứ n trong dãy Fibonacci
void fibonanci (int n) {

}
int main()
{
    int n;
    printf("nhap so cac so trong day fibonaci: ");
    scanf("%d",&n);
    fibonanci(n);
    return 0;
}
