#include <stdio.h>
#include <stdlib.h>
/*
TABEG010 - Tình yêu dành cho C
Hãy thể hiện tình yêu của bạn với ngôn ngữ C bằng việc in ra 4 dòng sau:
I want C!
I need C!
I love C!
C is 99% of my life!

Input


Output
Các dòng chữ theo yêu cầu, không thừa, không thiếu.
*/
int main()
{
    printf("I want C!\n");
    printf("I need C!\n");
    printf("I love C!\n");
    printf("C is 99%% of my life!");
    return 0;
}
