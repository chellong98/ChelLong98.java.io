#include <stdio.h>
#include <stdlib.h>
//Bài tập 4: Sao chép mảng
//Viết chương trình C để sao chép các phần tử của mảng này sang mảng khác.
int main()
{

    return 0;
}
