#include <stdio.h>
#include <stdlib.h>
//Bài tập 1: In dòng chữ Hello World
int main()
{
    printf("Hello World!");
    return 0;
}
